# git-exercises
Homework for Git exercises
