#!/usr/bin/env bash

echo "Some work" > work.txt
git add work.txt
git commit -m "Late work"